# z_ik
